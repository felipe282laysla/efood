import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyDHOGX44ux2GVe0w8MssAcCtcAwcOnAPUs",
  authDomain: "foodloja-9a919.firebaseapp.com",
  projectId: "foodloja-9a919",
  storageBucket: "foodloja-9a919.firebasestorage.app",
  messagingSenderId: "431927065978",
  appId: "1:431927065978:web:12651206d00d76f589aac3"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export default app;