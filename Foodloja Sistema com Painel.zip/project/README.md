# Delicia de Bom - Cardápio Digital

Sistema completo de cardápio digital com painel administrativo integrado ao Firebase.

## 🚀 Funcionalidades

### Para Clientes
- ✅ Visualização de produtos por categoria
- ✅ Carrinho de compras interativo
- ✅ Adicionais personalizáveis
- ✅ Envio de pedidos via WhatsApp
- ✅ Sistema de avaliações
- ✅ Desconto automático para usuários cadastrados (R$ 2,00)
- ✅ Participação automática em sorteios
- ✅ Modo escuro/claro
- ✅ Design responsivo

### Para Administradores
- ✅ Dashboard completo com estatísticas
- ✅ Gerenciamento de produtos
- ✅ Gerenciamento de categorias
- ✅ Sistema de adicionais globais
- ✅ Criação de promoções e combos
- ✅ Sistema de sorteios
- ✅ Gerenciamento de pedidos
- ✅ Gerenciamento de usuários
- ✅ Sistema de avaliações
- ✅ Configuração de horários de funcionamento
- ✅ Personalização de cores e temas
- ✅ Configuração de redes sociais
- ✅ Exportação de dados (Excel)
- ✅ Upload de imagens
- ✅ Banners promocionais

## 🔐 Acesso Administrativo

**Email:** admin@deliciabom.com  
**Senha:** admin123

## 🛠️ Tecnologias

- **Frontend:** React + TypeScript + Tailwind CSS
- **Backend:** Firebase (Firestore + Storage + Auth)
- **Deploy:** Netlify
- **Ícones:** Lucide React
- **Exportação:** XLSX

## 📱 Recursos Especiais

### Sistema de Usuários
- Cadastro manual pelo administrador
- Desconto automático de R$ 2,00 para usuários cadastrados
- Histórico de pedidos

### Sistema de Sorteios
- Participação automática baseada no valor mínimo
- Números da sorte únicos
- Gerenciamento de participantes
- Configuração flexível de regras

### Personalização Completa
- Cores personalizáveis
- Banners promocionais
- Redes sociais
- Horários de funcionamento
- Informações da empresa

### Exportação de Dados
- Produtos, pedidos, usuários, avaliações
- Formato Excel (.xlsx)
- Dados completos para análise

## 🚀 Deploy

O projeto está configurado para deploy automático no Netlify com:
- Build otimizado
- Redirects para SPA
- Headers de segurança
- Cache otimizado para assets

## 📊 Firebase Collections

- `products` - Produtos do cardápio
- `categories` - Categorias dos produtos
- `globalAddons` - Adicionais reutilizáveis
- `promotions` - Promoções e sorteios
- `orders` - Pedidos dos clientes
- `users` - Usuários cadastrados
- `reviews` - Avaliações dos clientes
- `giveawayParticipants` - Participantes dos sorteios
- `businessConfig` - Configurações da empresa
- `adminCredentials` - Credenciais do administrador

## 🎯 Próximos Passos

1. Acesse o painel administrativo
2. Configure as informações da empresa
3. Adicione produtos e categorias
4. Configure horários de funcionamento
5. Personalize cores e banners
6. Comece a receber pedidos!

---

**Desenvolvido com ❤️ para o sucesso do seu negócio!**